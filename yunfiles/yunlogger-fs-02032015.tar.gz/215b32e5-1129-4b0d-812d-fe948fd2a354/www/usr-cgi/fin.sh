#!/bin/sh
echo ' </div>'

echo ' <hr>'

echo ' <div id="footer">'
echo ' <h4><a href="'$1'">Volver</a></h4>'
echo ' </div>'

echo '</div>'
echo '</body>'
echo '</html>'
