
echo '<h3>Aplicaci&oacute;n General del AXPLC</h3>'
echo '<br>'

echo '<form action="/usr-cgi/axisfin.sh">'
echo '<input class="botond" type=submit value="Parar ">'
echo '</form>'

echo '<form action="/usr-cgi/axisini.sh">'
echo '<input class="botond" type=submit value="Reiniciar">'
echo '</form>'


echo '<h3>Procesos individuales</h3>'
echo '<br>'

echo '<form action="/usr-cgi/procesos.sh">'
echo '<input class="botond" type=submit value="Listar procesos">'
echo '</form>'


