#!/bin/sh
. ./inicioLigero.sh

$SAIHBD/bin/leeraxisbdcgi

./fin.sh /usr-cgi/configuracion.sh
