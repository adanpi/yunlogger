#!/bin/sh
. /www/usr-cgi/inicioLigero.sh

