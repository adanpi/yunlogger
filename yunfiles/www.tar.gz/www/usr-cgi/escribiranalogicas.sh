#!/bin/sh
. /www/usr-cgi/inicioLigero.sh

$SAIHBD/bin/escribiranalogicascgi

/www/usr-cgi/fin.sh /usr-cgi/configuracion.sh
