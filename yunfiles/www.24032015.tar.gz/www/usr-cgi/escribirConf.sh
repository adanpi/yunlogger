#!/bin/sh
. /www/usr-cgi/inicioLigero.sh

$SAIHBD/bin/escribirlogerbdcgi

/www/usr-cgi/fin.sh /usr-cgi/configuracion.sh
