#!/bin/sh
. ./inicioLigero.sh

cat $HTML_HOME/index.txt

echo '</div>'
echo '</body>'
echo '</html>'



