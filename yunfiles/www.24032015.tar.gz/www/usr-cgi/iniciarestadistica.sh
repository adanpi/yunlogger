#!/bin/sh
source ./inicio.sh

$SAIHBD/bin/leeraxisbd R

./fin.sh /usr-cgi/estadistica.sh
