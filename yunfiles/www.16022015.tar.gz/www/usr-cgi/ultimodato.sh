#!/bin/sh
. /www/usr-cgi/inicioLigero.sh

$SAIHBD/bin/leerlogerbd L

/www/usr-cgi//fin.sh /usr-cgi/inicioLigero.sh
