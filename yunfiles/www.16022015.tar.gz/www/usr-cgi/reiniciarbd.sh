
echo '<h3>Reiniciar bases de datos</h3>'
echo '<h5>Se borrar&aacute;n los datos almacenados en el Axis y a continuaci&oacute;n se reiniciar&aacute; el proceso axisloger</h5>'
echo '<br>'
echo '<form action=iniciarbd.sh method=POST>'
echo '<input type=hidden value="1" size=1 maxlen=1 name="numero">'
echo '<input class="botonc" type=submit value="Borrar Bases de Datos">'
echo '</form>'


