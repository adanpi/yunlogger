#!/bin/sh
source ./inicio.sh

./segjulhistcgi

./fin.sh /usr-cgi/supervision.sh
