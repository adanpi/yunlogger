#!/bin/sh
. /www/usr-cgi/inicioLigero.sh

$SAIHBD/bin/incidenciascgi

/www/usr-cgi/fin.sh /usr-cgi/incidencias.sh
