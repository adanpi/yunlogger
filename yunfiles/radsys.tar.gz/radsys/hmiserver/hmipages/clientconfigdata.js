// The client ID string. Replace this with your own client id.
MBT_ClientID = "adan";

// HMI scan in milliseconds. The web browser will poll the server at the
// interval defined here.
MBT_ScanRate = 3000;

// This is the title of the page.
MBT_PageTitle = "Hidro"

// This determines whether the page heading is visible or not.
MBT_HeaderVisible = true;

