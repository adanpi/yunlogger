#./hmiserver/hmiservermbc.py -p 8082 -h yun -r 502 -u 1 -t 30.0
#./hmiserver/hmiservermbc.py -p 8082 -h 127.0.0.1 -r 502 -u 1 -t 30.0
python hmiserver/hmiservermbc.py -p 8082 -h 127.0.0.1 -r 502 -u 1 -t 30.0
